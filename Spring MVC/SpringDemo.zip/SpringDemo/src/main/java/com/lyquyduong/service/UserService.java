package com.lyquyduong.service;

import com.lyquyduong.model.UserDTO;

public interface UserService {

	public UserDTO getByUsername(String user);
}
