//DepartmentDao.java

/*
 * =============================================================================
 * Copyright (c) Santosh Kumar Kar. All rights reserved.
 * 
 * This file you have downloaded  is copyright of Santosh Kumar Kar
 *
 * I have made every effort and taken great care in making sure that the source
 * code and other content included on my presentations is technically accurate, 
 * but I disclaim any and all responsibility for any loss, damage or destruction 
 * of data or any other property which may arise from relying on it. I will in no
 * case be liable for any monetary damages arising from such loss, damage or
 * destruction.
 * 
 * =============================================================================
 */

package org.santosh.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.santosh.vo.Department;

public class DepartmentDao{
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public Department getDepartmentById(long id){
		return (Department)sessionFactory.getCurrentSession().get(Department.class, id);
	}


	public void addDepartment(Department dept) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(dept);
		tx.commit();
	}

	public void deleteDepartment(int deptid) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.delete(new Department(deptid));
		tx.commit();
	}
}
