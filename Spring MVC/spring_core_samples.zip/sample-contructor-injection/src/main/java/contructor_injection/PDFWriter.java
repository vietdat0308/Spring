package contructor_injection;

public class PDFWriter {

	public void writeData(){
		System.out.println("Write data into pdf file.");
	}
	
}
