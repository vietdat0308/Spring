package no_ioc;

public class ReportGeneratorTest {

	public static void main(String[] args) {
		
		ReportGenerator generator = new ReportGenerator();
		generator.generateReport();
	}

}
