package hello;

public class HelloSpring {
	
	private String message;

	public String getMessage() {
		return "Your message: " + message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
